package modele.domaine;

public class Produit {
    private int id;
    private String code;
    private String designation;
    private double prix;
    private int categorieId; // clé étrangère vers la table Categorie

    public Produit() {}

    public Produit(String code, String designation, double prix, int categorieId) {
        this.code = code;
        this.designation = designation;
        this.prix = prix;
        this.categorieId = categorieId;
    }

    public Produit(int id, String code, String designation, double prix, int categorieId) {
        this.id = id;
        this.code = code;
        this.designation = designation;
        this.prix = prix;
        this.categorieId = categorieId;
    }

    // Getters et Setters
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }

    public String getCode() {
        return code;
    }
    public void setCode(String code) {
        this.code = code;
    }

    public String getDesignation() {
        return designation;
    }
    public void setDesignation(String designation) {
        this.designation = designation;
    }

    public double getPrix() {
        return prix;
    }
    public void setPrix(double prix) {
        this.prix = prix;
    }

    public int getCategorieId() {
        return categorieId;
    }
    public void setCategorieId(int categorieId) {
        this.categorieId = categorieId;
    }
}
