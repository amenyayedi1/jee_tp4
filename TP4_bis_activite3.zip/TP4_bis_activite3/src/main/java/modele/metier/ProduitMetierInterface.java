package modele.metier;

import modele.domaine.Produit;
import java.util.List;

public interface ProduitMetierInterface {

    // Méthode pour ajouter un produit
    void ajouterProduit(Produit produit);
    
    // Méthode pour lister tous les produits
    List<Produit> getAllProduits();

    // Méthode pour obtenir un produit par son ID
    Produit getProduitById(int id);
    
    // Méthode pour modifier un produit
    void modifierProduit(Produit produit);

    // Méthode pour supprimer un produit
    void supprimerProduit(int id);
}
