package modele.metier;

import java.util.List;
import modele.domaine.Categorie;

public interface CategorieMetierInterface {
    void ajouterCategorie(Categorie c);
    void modifierCategorie(Categorie c);
    List<Categorie> listerCategories();
    Categorie getCategorieById(int id);
}
