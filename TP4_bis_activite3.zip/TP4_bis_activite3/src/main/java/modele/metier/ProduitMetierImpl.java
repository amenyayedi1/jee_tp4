package modele.metier;

import modele.dao.DBConnexion;
import modele.domaine.Produit;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProduitMetierImpl implements ProduitMetierInterface {

	public void insertProduit(Produit produit) {
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement ps = con.prepareStatement("INSERT INTO Produit(code, designation, prix, categorie_id) VALUES (?, ?, ?, ?)")) {
            ps.setString(1, produit.getCode());
            ps.setString(2, produit.getDesignation());
            ps.setDouble(3, produit.getPrix());
            ps.setInt(4, produit.getCategorieId()); // Référence de la catégorie
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Lister tous les produits
    public List<Produit> getAllProduits() {
        List<Produit> produits = new ArrayList<>();
        try (Connection con = DBConnexion.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Produit")) {
            while (rs.next()) {
                Produit produit = new Produit(
                    rs.getInt("id"),
                    rs.getString("code"),
                    rs.getString("designation"),
                    rs.getDouble("prix"),
                    rs.getInt("categorie_id") // Récupérer la catégorie_id
                );
                produits.add(produit);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return produits;
    }

	@Override
	public void ajouterProduit(Produit produit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Produit getProduitById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void modifierProduit(Produit produit) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void supprimerProduit(int id) {
		// TODO Auto-generated method stub
		
	}
}