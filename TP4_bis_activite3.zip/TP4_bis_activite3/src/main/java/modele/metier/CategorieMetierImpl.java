package modele.metier;

import java.sql.*;
import java.util.*;

import modele.dao.DBConnexion;
import modele.domaine.Categorie;

public class CategorieMetierImpl implements CategorieMetierInterface {

    
    public void ajouter(Categorie c) {
        try (Connection con = DBConnexion.getConnection();
             PreparedStatement ps = con.prepareStatement("INSERT INTO Categorie(code, libelle) VALUES (?, ?)")) {
            ps.setString(1, c.getCode());
            ps.setString(2, c.getLibelle());
            ps.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // Lister les catégories
    public List<Categorie> getAll() {
        List<Categorie> list = new ArrayList<>();
        try (Connection con = DBConnexion.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery("SELECT * FROM Categorie")) {

            while (rs.next()) {
                Categorie c = new Categorie();
                c.setId(rs.getInt("id"));
                c.setCode(rs.getString("code"));
                c.setLibelle(rs.getString("libelle"));
                list.add(c);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

	@Override
	public void ajouterCategorie(Categorie c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void modifierCategorie(Categorie c) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public List<Categorie> listerCategories() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Categorie getCategorieById(int id) {
		// TODO Auto-generated method stub
		return null;
	}
}
