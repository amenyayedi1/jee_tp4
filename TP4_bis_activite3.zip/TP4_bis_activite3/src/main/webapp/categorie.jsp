<%@page import="modele.metier.CategorieMetierImpl"%>
<%@page import="modele.domaine.Categorie"%>
<%@page import="java.util.List"%>

<%
    CategorieMetierImpl metier = new CategorieMetierImpl();
    List<Categorie> categories = metier.getAll();
%>

<h2>Liste des cat�gories</h2>
<table border="1">
    <tr><th>ID</th><th>Code</th><th>Libell�</th></tr>
    <%
        for (Categorie c : categories) {
    %>
    <tr>
        <td><%=c.getId()%></td>
        <td><%=c.getCode()%></td>
        <td><%=c.getLibelle()%></td>
    </tr>
    <% } %>
</table>
